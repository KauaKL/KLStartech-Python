# Twilio (WhatsApp)
"""
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy
TWILIO_WHATSAPP_FROM=whatsapp:+1415xxxxxxx
ALERT_WHATSAPP_TO=whatsapp:+55xxxxxxxxxx  # opcional se inserir no app
"""
